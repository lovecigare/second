﻿Public Class InfoBrief

    Public Shared PortDownloadServer As Integer = 0
    Public Shared PortUploadServer As Integer = 0

End Class
