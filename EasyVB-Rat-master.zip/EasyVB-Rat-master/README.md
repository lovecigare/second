EasyVB-Rat
==========

This is a Rat! This was written in VisualBasic 2012

REUPLOAD
========

Ich bin ein Entwickler von diesen RAT und wollte es mal weiterführen da die Entwicklung eingestellt wurde.


TODO
====

- ~~Downloadserver + Uploadeserver~~
- _Downloadclient_ + Uploadclient <- Working ...
- Edit File Browser
- Added Desktop Screen
- Added Reading Volumes


VIDEO
=====

https://www.youtube.com/watch?v=T5rEJeZX_gU


Virus Scan
==========

VirusTotal: https://www.virustotal.com/de/file/2d8447abd77715bd7b389a547d597ee473b745e04793cca0e59ecdeda0d9d81f/analysis/1457386219/